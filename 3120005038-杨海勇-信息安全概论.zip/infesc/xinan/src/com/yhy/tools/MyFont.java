package com.yhy.tools;

import java.awt.*;

/**
 * gui界面字体函数
 * @author: 杨海勇
 **/
public class MyFont {

    public static Font setFont(){
        Font f=new Font("楷体",Font.BOLD,18);//根据指bai定字体名du称、样式和磅值大小，创建一个新zhi Font。
        return f;
    }

}
